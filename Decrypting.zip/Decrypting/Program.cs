﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Decrypting
{
    class Program
    {
        public static string EncryptedText { get; } = "EDAHPIOKEADPMAACKDAHPEHMHCDKKHNIIHAFHMAFAHCCKHNHIAMJHIAKAKCKKIFKDBNNHAANAHCADFOAOA" +
            "FAOPNJAAOMNJHCOMAEAJKAIIAAOEAJBAGAPAMNCFDKEGFIICIHCGNFANMAKOKAANAOOADNDKNEAIAJADIPKMIFHFKKAGKIHHOFEHACAHMAHFOAIHOFH" +
            "IJKPACDOAOHIOJOEJJAPAIHKAEFHMAEAJAAAFAMDGAEECHCEADAHMMAMECJAHHHHAKAIADFNJCGNKCIIPODICOKOKMIEFNGOAFNNAECMAFHGOPOAOAN" +
            "AONAFIJANOGOACAKAFNNOANAMKAICJAAAOKKFKAKHAIAMFHHHCFKCHKIEHPFCGMFCOMDMODEBOGOAHEHBDAMEPFCHMICACMMEDNADHOAAEABJICOHKA" +
            "HNIAFAMHCIAMACOODAICPGAAJFAMAEOHMFNNCHHPFHAANAACNHJDABAAJKAMAEACOEJNIICAKHMAFJKDMOIACHEAJIFOHOOKNCNAAAHAFAIKKIKFCNK" +
            "NHAMOEKHACJOKEAIEBAMHEIHOHIAKHAACFFDAHJINKAFAOHGAIGMJEHIHKHKCMFIACHFIGHIOKIOCAHIOAOAEAAJHEFANONJMIAOHICOFEIAMCNACHB" +
            "ACAAFMHEAAOEJMIIACAJMFFGKACKICHDAIAIFDHPNKADAOJDKIKPOAOAHDADFOAACIHKDADJOONAOKGEAAJAADFHAAKMJNIIHHHEAKACMMAOECJFKCI" +
            "APODIONNHNMAAOGIAFFHNAFCNAFHOMKECHOHIJMAOPCAAKECACNMAAAFNAMAHKDIEPFDGAMODADOADIEHAKNIACANAOJIOCOBAHAFNEAOAMJEFAAAIO" +
            "OIDAOIPAIKFJMIJDADDOOKPEOHFANIPADAOKMHIFCJAHAIBKEIHONAFCAHHAFFIMKEFHMCAAEEFEGOIOOIAECMAMHMOENKADAPFCAFNMJFAHAIEIIEM" +
            "OFHCHGIFKMNJKAIOBHONCFFMHEAPADANNNHOCAOACAIKOCIIOMNEMCIAIJJEKMIMAOOEONFKOIIHICENOACGNAHMJEIHKDIAOHCAAHCCHCNAEABDFKM" +
            "PCIAAIJPNKFIADFNJKGACAHHAMNEAHOAANIPKEINJDAPDFMDPMEEMNECPADAHMCMHOHJAIAIEKMIHONAFKAOJEPHAFNGMHFOCDGAKGIHHMCEDHKADFI" +
            "INAGOAONIHNAOFAJKAIJEJOAKMMKKCKIHAIJEOAEAOMMHOKCICAHAHAHAKAAKINJONPAIFNHOFKONGDIAOAIHHKCIMHFACANEMJEHOFEANCHMAAFHDH" +
            "DAAOFIONACICAAICEFIKKIDHNAHMANCAHHINOOADNOANAKKACIPDDPNKAJANAPAAADENIONLAHANAEOIEEACAHDIOMHKICDIDJIMKCFAKKGKIINJAJG" +
            "AFACACKCEHGANAAOANANNAFABAHOENIAMAEAOHCAMHFCAKIBIEEMOFHCAGAPDOIACADLOIADLEIFKMJJIAEAANKACOHAFAIEAIANOCDAHHMAHAHOAOA" +
            "JDCFKHHIHIFFACAHKHFOIKGAAEJDEIMEMDNACMOACAHAECOHNADNANPPMBBBGANJDEMDDME";

        public static List<Example> Examples { get; } = new List<Example>
        {
            new Example { Text = "гражданс", EncryptedText = "NACJNADNDCONBHMA" }, // Разбивка на блоки.
            new Example { Text = "кую войн", EncryptedText = "AIJEFINKOOHJAOAP" }, // Разбивка на блоки.
            new Example { Text = "у", EncryptedText = "BMBBBBOMOMMMMBMB" }, // Разбивка на блоки.
            new Example { Text = "в Крыму", EncryptedText = "HOBOMHHDFAFJCAMK" }, // Исходный текст.
            new Example { Text = "гражданскую войну", EncryptedText = "NACJNADNDCONBHMAAIJEFINKOOHJAOAPBMBBBBOMOMMMMBMB" }, // Исходный текст.


        };

        public static IEnumerable<string> Texts => Examples.Select(e => e.Text);

        public static IEnumerable<string> EncryptedTexts => Examples.Select(e => e.EncryptedText).Union(new string[] { EncryptedText });

        static void Main(string[] args)
        {
            var decrypter = new Decrypter();

            decrypter.GetUsedSymbols(Texts)
                .ForEach(s => Console.Write($"{s} "));
            Console.WriteLine();

            foreach (var example in Examples)
            {
                Console.WriteLine(example.Text);
                decrypter.GetUsedSymbols(example.EncryptedText)
                    .ForEach(s => Console.Write($"{s} "));
                Console.WriteLine();
            }

            var result = decrypter.Analyze(Examples[4].EncryptedText);

            Console.WriteLine();
            Console.WriteLine(result);

            var result3 = decrypter.Analyze(Examples[3].EncryptedText);

            Console.WriteLine();
            Console.WriteLine(result3);

            var result2 = decrypter.Analyze(EncryptedText);
            Console.WriteLine();
            Console.WriteLine(result2);
            using (var sw = new StreamWriter("output.txt"))
                sw.WriteLine(result2);


                Console.WriteLine();
            Console.WriteLine();
            foreach (var item in decrypter.Symbols)
                Console.WriteLine($"{item.Key} - {item.Value}");

            Console.ReadKey();
        }
    }
}
